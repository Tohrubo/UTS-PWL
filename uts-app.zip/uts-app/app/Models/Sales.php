<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Sales extends Model
{
    use HasFactory;
    protected $table = 'sales';
    protected $primaryKey = 'purchase_number';
    public $incrementing = false;
    protected $keyType = 'integer';
    protected $fillable = ['purchase_number', 'date_of_purchase', 'customer_id', 'item_code'];
    public $timestamps = true;

    // Relasi ke Customer
    public function customers()
    {
        return $this -> belongsTo(Customers::class, 'customer_id', 'customer_id');
    }
    
    // Relasi ke Items
    public function items()
    {
        return $this -> belongsTo(Items::class, 'item_code', 'item_code');
    }
}
