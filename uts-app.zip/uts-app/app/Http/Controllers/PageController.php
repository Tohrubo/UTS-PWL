<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    public function home()
    {
        $menu = 'home';
        return view('home', compact('menu'));
    }

    public function courses()
    {
        $menu = 'courses';
        return view('courses', compact('menu'));
    }

    public function grades()
    {
        $menu = 'grades';
        return view('grades', compact('menu'));
    }

    public function students()
    {
        $menu = 'students';
        return view('students', compact('menu'));
    }

    public function assignments()
    {
        $menu = 'assignments';
        return view('assignments', compact('menu'));
    }

    public function proses()
    {
        $name = request('name');
        $nim = request('nim');
        $menu = 'home';
        return view('results', compact('name', 'nim', 'menu'));
    }
}
