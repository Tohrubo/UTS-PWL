
<?php $__env->startSection('title', '.:Result:.'); ?>
<?php $__env->startSection('article'); ?>
Result
<br>
Nama:       <?php echo e($name); ?>

<br>
NIM:        <?php echo e($nim); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.parent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\micha\OneDrive\Documents\College\7SMT\testing\uts-app\resources\views/results.blade.php ENDPATH**/ ?>