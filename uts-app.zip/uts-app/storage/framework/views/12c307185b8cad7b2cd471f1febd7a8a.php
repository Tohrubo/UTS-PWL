<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>
    <div class="container-fluid">
        <!-- HEADER -->
        <div class="row">
            <div class="col-md-12 border bg-primary py-3"></div>
        </div>

        <!-- BODY -->  
        <div class="row">
            <div class="col-md-2 border bg-black vh-100">
                <?php echo $__env->make('main.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="col-md-8 border vh-100">
                <?php echo $__env->yieldContent('article'); ?>
            </div>
            <div class="col-md-2 border bg-black vh-100">
                <?php echo $__env->make('main.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>

        <!-- FOOTER -->
        <div class="row">
            <div class="col-md-12 border bg-primary py-3"></div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH C:\Users\micha\OneDrive\Documents\College\7SMT\testing\uts-app\resources\views/main/parent.blade.php ENDPATH**/ ?>