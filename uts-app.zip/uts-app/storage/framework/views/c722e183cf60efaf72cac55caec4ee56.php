
<?php $__env->startSection('title', '.:Home:.'); ?>
<?php $__env->startSection('article'); ?>
<form action="/proses" method="post">
        <?php echo csrf_field(); ?>
        <table border="1" style="border-collapse: collapse;">
            <tr>
                <td><label for="namein">Nama</label></td>
                <td><input type="text" name="name"></td>
            </tr>
            <tr>
                <td><label for="nimin">NIM</label></td>
                <td><input type="number" name="nim"></td>
            </tr>
            <tr>
                <td><button type="submit">Send</button></td>
            </tr>
        </table>        
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.parent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\micha\OneDrive\Documents\College\7SMT\testing\uts-app\resources\views/home.blade.php ENDPATH**/ ?>