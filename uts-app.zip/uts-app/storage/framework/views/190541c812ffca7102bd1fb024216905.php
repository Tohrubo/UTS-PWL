
<?php $__env->startSection('title', '.:Grades:.'); ?>
<?php $__env->startSection('article'); ?>
<h1>Grades Page</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.parent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\micha\OneDrive\Documents\College\7SMT\testing\uts-app\resources\views/grades.blade.php ENDPATH**/ ?>