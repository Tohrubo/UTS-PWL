<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sales', function (Blueprint $table) {
            $table->integer('purchase_number')->primary();
            $table->date('date_of_purchase')->nullable();
            $table->unsignedBigInteger('customer_id')->nullable();
            $table->char('item_code', 8)->nullable();
            $table->timestamps();

            // Foreign Key to Customers
            $table->foreign('customer_id')
                -> references('customer_id')
                -> on('customers')
                -> restrictOnDelete()
                -> cascadeOnUpdate();

            // Foreign Key to Items
            $table->foreign('item_code')
                -> references('item_code')
                -> on('items')
                -> restrictOnDelete()
                -> cascadeOnUpdate();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sales');
    }
};
