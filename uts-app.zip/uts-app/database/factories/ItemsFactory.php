<?php

namespace Database\Factories;

use App\Models\Items;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Items>
 */
class ItemsFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'item_code' => fake() -> unique() -> numerify('########'),
            'item' => fake(),
            'unit_price' => fake() -> numerify('#######'),
        ];
    }
}
