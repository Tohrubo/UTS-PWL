@extends('main.parent')
@section('title', '.:Students:.')
@section('article')
<h1>Students Page</h1>
@endsection