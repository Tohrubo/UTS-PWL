@extends('main.parent')
@section('title', '.:Grades:.')
@section('article')
<h1>Grades Page</h1>
@endsection