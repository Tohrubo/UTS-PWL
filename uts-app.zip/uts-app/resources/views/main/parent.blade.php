<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title')</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>
    <div class="container-fluid">
        <!-- HEADER -->
        <div class="row">
            <div class="col-md-12 border bg-primary py-3"></div>
        </div>

        <!-- BODY -->  
        <div class="row">
            <div class="col-md-2 border bg-black vh-100">
                @include('main.nav')
            </div>
            <div class="col-md-8 border vh-100">
                @yield('article')
            </div>
            <div class="col-md-2 border bg-black vh-100">
                @include('main.nav')
            </div>
        </div>

        <!-- FOOTER -->
        <div class="row">
            <div class="col-md-12 border bg-primary py-3"></div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>