<div class="d-flex align-items-start mt-3">
  <div class="nav flex-column nav-pills me-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
    <a class="nav-link {{ ($menu == 'home') ? 'active':'' }}" href="/" type="button">Home</a>
    <a class="nav-link {{ ($menu == 'courses') ? 'active':'' }}" href="/courses" type="button">Courses</a>
    <a class="nav-link {{ ($menu == 'students') ? 'active':'' }}" href="/students" type="button">Students</a>
    <a class="nav-link {{ ($menu == 'grades') ? 'active':'' }}" href="/grades" type="button">Grades</a>
    <a class="nav-link {{ ($menu == 'assignments') ? 'active':'' }}" href="/assignments" type="button">Assignments</a>
  </div>
</div>