@extends('main.parent')
@section('title', '.:Result:.')
@section('article')
Result
<br>
Nama:       {{ $name }}
<br>
NIM:        {{ $nim }}
@endsection