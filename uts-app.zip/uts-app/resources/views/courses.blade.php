@extends('main.parent')
@section('title', '.:Courses:.')
@section('article')
<h1>Courses Page</h1>
@endsection