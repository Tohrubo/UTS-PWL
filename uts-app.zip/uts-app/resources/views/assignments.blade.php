@extends('main.parent')
@section('title', '.:Assignments:.')
@section('article')
<h1>Assignment Page</h1>
@endsection