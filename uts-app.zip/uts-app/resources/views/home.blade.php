@extends('main.parent')
@section('title', '.:Home:.')
@section('article')
<form action="/proses" method="post">
        @csrf
        <table border="1" style="border-collapse: collapse;">
            <tr>
                <td><label for="namein">Nama</label></td>
                <td><input type="text" name="name"></td>
            </tr>
            <tr>
                <td><label for="nimin">NIM</label></td>
                <td><input type="number" name="nim"></td>
            </tr>
            <tr>
                <td><button type="submit">Send</button></td>
            </tr>
        </table>        
    </form>
@endsection